﻿namespace winPEAS.Native.Enums
{
	public enum SECURITY_IMPERSONATION_LEVEL
    {
        Anonymous,
        Identification,
        Impersonation,
        Delegation
    }
}
